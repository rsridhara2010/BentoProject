package com.test.model;
public class WikiPediaRequest {
 
    
    private String requestURL;
    
    
    public String getRequestURL() {
        return requestURL;
    }
 
    public void setRequestURL(String requestURL) {
        this.requestURL = requestURL;
    }
 
}